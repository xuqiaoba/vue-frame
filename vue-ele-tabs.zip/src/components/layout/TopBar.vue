<template>
  <div class="top-bar">
    <div class="logo">
      <h1>LOGO</h1>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
.top-bar {
  height: 100%;
}

.logo {
  height: 100%;
  float: left;
  color: #409eff;
  display: flex;
  align-items: center;
}
</style>
