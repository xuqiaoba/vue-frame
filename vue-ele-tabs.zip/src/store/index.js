import Store from './store'
require('./menuModule')

export default Store
