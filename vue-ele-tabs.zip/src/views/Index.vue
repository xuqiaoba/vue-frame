<template>
  <div class="index">
    <h1>首页</h1>
  </div>
</template>
